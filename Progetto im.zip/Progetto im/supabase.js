const SUPABASE_URL  = 'https://czxvgizomkfmqafavvqn.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN6eHZnaXpvbWtmbXFhZmF2dnFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4MTA1NTksImV4cCI6MjA3NDM4NjU1OX0.88MEdobvz9W0EgRcuWBaNBl6saueM00RiGxGXuDjA7s';

export const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON);