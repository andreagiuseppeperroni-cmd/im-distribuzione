import { sb } from './supabase.js';

// catalogo
async function loadCatalogo() {
  const { data, error } = await sb.from('products').select('*').order('name');
  const grid = document.getElementById('prod-grid');
  if (error) { grid.innerHTML = `<p>Errore: ${error.message}</p>`; return; }
  if (!data.length) { grid.innerHTML = '<p>Nessun prodotto disponibile.</p>'; return; }
  grid.innerHTML = data.map(p => `
    <div class="card-prod">
      <img src="${p.image_url}" alt="${p.name}" onerror="this.style.display='none'">
      <h3>${p.name}</h3>
      <p>${p.description || ''}</p>
      <strong>€ ${Number(p.price || 0).toFixed(2)}</strong>
    </div>`).join('');
}
loadCatalogo();

// form contatti
document.getElementById('contactForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const obj = Object.fromEntries(new FormData(e.target));
  const { error } = await sb.from('contacts').insert([obj]);
  const msg = document.getElementById('formMsg');
  msg.classList.remove('hide');
  if (error) { msg.style.color = 'red'; msg.textContent = 'Errore: ' + error.message; }
  else { msg.style.color = 'green'; msg.textContent = 'Messaggio inviato! Grazie.'; e.target.reset(); }
});